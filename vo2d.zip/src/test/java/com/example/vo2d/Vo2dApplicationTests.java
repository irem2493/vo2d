package com.example.vo2d;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Vo2dApplicationTests {

    @Test
    void contextLoads() {
    }

}
