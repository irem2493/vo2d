package com.example.vo2d;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Vo2dApplication {

    public static void main(String[] args) {
        SpringApplication.run(Vo2dApplication.class, args);
    }

}
