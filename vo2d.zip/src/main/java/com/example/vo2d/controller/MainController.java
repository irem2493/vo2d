package com.example.vo2d.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.Clock;

@Controller
public class MainController {
    @RequestMapping("/")
    public String main(){
        System.out.println("main...");
        return "main";
    }
}
